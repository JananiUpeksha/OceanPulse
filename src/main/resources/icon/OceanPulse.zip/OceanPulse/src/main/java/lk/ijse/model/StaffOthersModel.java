package lk.ijse.model;

public class StaffOthersModel {
}
