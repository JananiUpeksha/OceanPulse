package lk.ijse.model;

import lk.ijse.db.Dbconnection;
import lombok.*;

import java.sql.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderModel {
    private String o_id;
    private String date;
    private String qty;
    private String c_id;
    private String s_id;

 /*   public static String generateNextOrderId() throws SQLException {
        Connection connection = Dbconnection.getInstance().getConnection();

        String sql = "SELECT o_id FROM orders ORDER BY o_id DESC LIMIT 1";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet resultSet = pstm.executeQuery();
        if(resultSet.next()) {
            return splitOrderId(resultSet.getString(1));
        }
        return splitOrderId(null);
    }*/

   /* private static String splitOrderId(String currentOrderId) {
        if(currentOrderId != null) {
            String[] split = currentOrderId.split("R0");

            int id = Integer.parseInt(split[0]); //01
            id++;
            return "R00" + id;
        } else {
            return "R001";
        }
    }*/

    public static boolean saveOrder(String o_Id, LocalDate date, int qty, String c_id, String s_id) throws SQLException {
        Connection connection = Dbconnection.getInstance().getConnection();

        String sql = "INSERT INTO orders VALUES(?, ?, ?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, o_Id);
        pstm.setDate(2, Date.valueOf(date));
        pstm.setInt(3,qty);
        pstm.setString(4,c_id);
        pstm.setString(5,s_id);

        return pstm.executeUpdate() > 0;
    }


    public boolean saveOrderDetails(String id, String iId) throws SQLException {
        Connection connection = Dbconnection.getInstance().getConnection();

        String sql = "INSERT INTO order_detail VALUES(?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, id);
        pstm.setString(2, iId);



        return pstm.executeUpdate() > 0;
    }
}
