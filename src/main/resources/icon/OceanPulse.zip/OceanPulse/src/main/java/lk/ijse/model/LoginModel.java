package lk.ijse.model;

public class LoginModel {
}
